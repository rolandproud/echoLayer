==========
pyechomask
==========
An echogram classification tool (in development)
------------------------------------------------

developed by Roland Proud (rp43@st-andrews.ac.uk)

Pelagic Ecology Research Group, University of St Andrews

